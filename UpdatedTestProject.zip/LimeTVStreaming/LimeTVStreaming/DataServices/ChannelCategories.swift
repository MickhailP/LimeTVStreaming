//
//  ChannelCategories.swift
//  LimeTVStreaming
//
//  Created by Миша Перевозчиков on 04.12.2022.
//

import Foundation

enum Categories: String {
    case all = "Все"
    case favourites = "Избранные"
}
